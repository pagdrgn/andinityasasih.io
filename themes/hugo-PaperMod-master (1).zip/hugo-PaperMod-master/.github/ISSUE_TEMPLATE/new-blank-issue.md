---
name: New Blank Issue
about: Anything other than bug report
title: ""
labels: ""
assignees: ""
---
